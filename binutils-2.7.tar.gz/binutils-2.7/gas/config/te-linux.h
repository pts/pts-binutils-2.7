#define TE_LINUX
#define LOCAL_LABELS_FB 1

#include "obj-format.h"
